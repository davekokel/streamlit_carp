# Streamlit Pages Backup (2025-09-14T064644Z)

Included files:
- link_fish_to_new_tanks_1.py
- link_fish_to_new_tanks_2.py
- link_fish_to_new_tanks_3.py
- link_fish_to_new_tanks_4.py
- link_fish_to_new_tanks_5.py
- link_fish_to_new_tanks_6.py
- link_fish_to_tanks_10.py
- link_fish_to_tanks_11.py
- link_fish_to_tanks_7.py
- link_fish_to_tanks_8.py
- link_fish_to_tanks_9.py

## Restore
1. Copy the `.py` files into your app's `pages/` folder.
2. Make sure `st.secrets["supabase"]` contains `url`, `anon_key` (and optionally `service_role_key` for server-side writes).
3. Run Streamlit as usual: `streamlit run app.py`

> These pages assume your DB schema as of today (fish/tanks/fish_tank_memberships, enum site_code, optional tank_type).

